from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required, user_passes_test
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login, logout
from .models import Product, Category
from .forms import ProductForm, CategoryForm
import os
import json

def is_admin(user):
    return user.is_superuser
    
    # Initialize categories.json if it doesn't exist
    if not os.path.exists(CATEGORIES_JSON):
        initial_categories = [
            {"id": 1, "name": "Fruits"},
            {"id": 2, "name": "Vegetables"},
            {"id": 3, "name": "Bakery"},
            {"id": 4, "name": "Dairy"}
        ]
        save_json(CATEGORIES_JSON, initial_categories)



# Authentication views
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            return redirect('admin_dashboard')
        else:
            return render(request, 'market/login.html', {'error': 'Invalid credentials'})
            
    return render(request, 'market/login.html')
    
    return render(request, 'market/login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
@user_passes_test(is_admin)
def admin_dashboard(request):
    return render(request, 'market/admin_dashboard.html', {'user': request.user})

# Views
def home(request):
    """Home page view"""
    products = Product.objects.all()
    categories = Category.objects.all()
    return render(request, 'market/home.html', {
        'products': products,
        'categories': categories
    })

def product_list(request):
    products = Product.objects.all()
    return render(request, 'market/product_list.html', {'products': products})
    
@login_required
@user_passes_test(is_admin)
def product_list_admin(request):
    products = Product.objects.all()
    return render(request, 'market/product_list_admin.html', {'products': products, 'admin_view': True})

@csrf_exempt
def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    return render(request, 'market/product_detail.html', {'product': product})

@login_required
@user_passes_test(is_admin)
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('product_list_admin')
    else:
        form = ProductForm()
    return render(request, 'market/product_form.html', {'form': form, 'action': 'Add'})

@login_required
@user_passes_test(is_admin)
def edit_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            return redirect('product_list_admin')
    else:
        form = ProductForm(instance=product)
    return render(request, 'market/product_form.html', {'form': form, 'action': 'Edit'})

@login_required
@user_passes_test(is_admin)
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        product.delete()
        return redirect('product_list_admin')
    
    return render(request, 'market/product_confirm_delete.html', {
        'product': product
    })

# Category management
@csrf_exempt
def category_list(request):
    """List all categories"""
    categories = Category.objects.all()
    return render(request, 'market/category_list.html', {
        'categories': categories,
        'admin_view': True  # This enables the admin controls
    })

@csrf_exempt
@user_passes_test(is_admin)
def add_category(request):
    """Add a new category"""
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('category_list')
    else:
        form = CategoryForm()
    return render(request, 'market/add_category.html', {'form': form})

@csrf_exempt
@user_passes_test(is_admin)
def edit_category(request, category_id):
    """Edit a category"""
    category = get_object_or_404(Category, id=category_id)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            return redirect('category_list')
    else:
        form = CategoryForm(instance=category)
    return render(request, 'market/edit_category.html', {'form': form, 'category': category})

@csrf_exempt
def delete_category(request, category_id):
    """Delete a category"""
    if request.method in ['POST', 'DELETE']:
        category = get_object_or_404(Category, id=category_id)
        category.delete()
        
        # Return JSON response if AJAX request, otherwise redirect
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'status': 'success'})
    
    return redirect('category_list')

# API endpoints for AJAX requests
def api_products(request):
    """API endpoint for products"""
    products = Product.objects.all()
    return JsonResponse([{'id': p.id, 'name': p.name, 'price': p.price, 'price_currency': 'IQD', 'stock': p.stock} for p in products], safe=False)

def api_categories(request):
    """API endpoint for categories"""
    categories = Category.objects.all()
    return JsonResponse([{'id': c.id, 'name': c.name} for c in categories], safe=False)

def api_product(request, product_id):
    """API endpoint for a single product"""
    product = get_object_or_404(Product, id=product_id)
    return JsonResponse({'id': product.id, 'name': product.name, 'price': product.price, 'price_currency': 'IQD', 'stock': product.stock})

# Simple inventory management
@csrf_exempt
@user_passes_test(is_admin)
def update_stock(request, product_id):
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'error': 'Invalid method'}, status=405)

    try:
        data = json.loads(request.body)
        operation = data.get('operation')
        quantity = int(data.get('quantity', 0))

        product = get_object_or_404(Product, id=product_id)

        # Update stock based on operation
        current_stock = product.stock
        if operation == 'add':
            product.stock = current_stock + quantity
        elif operation == 'subtract':
            if current_stock < quantity:
                return JsonResponse({'status': 'error', 'error': 'Insufficient stock'}, status=400)
            product.stock = current_stock - quantity
        elif operation == 'set':
            product.stock = quantity
        else:
            return JsonResponse({'status': 'error', 'error': 'Invalid operation'}, status=400)

        product.save()

        return JsonResponse({
            'status': 'success',
            'product': {
                'id': product.id,
                'name': product.name,
                'stock': product.stock
            }
        })

    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'error': 'Invalid JSON'}, status=400)
    except ValueError:
        return JsonResponse({'status': 'error', 'error': 'Invalid quantity'}, status=400)
