from django import forms
from .models import Product, Category, CartItem

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'category', 'description', 'price', 'stock', 'image']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
            'price': forms.NumberInput(attrs={'step': '0.01', 'min': '0', 'placeholder': 'Price in IQD'}),
            'stock': forms.NumberInput(attrs={'min': '0'}),
        }
        labels = {
            'price': 'Price (IQD)',
        }

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

class CartItemForm(forms.ModelForm):
    preferred_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date'}),
        help_text='Select your preferred delivery date'
    )
    
    class Meta:
        model = CartItem
        fields = ['first_name', 'last_name', 'location', 'phone_number', 
                 'contact_method', 'availability_time', 'preferred_date']
        widgets = {
            'location': forms.TextInput(attrs={'placeholder': 'Your address or location'}),
            'phone_number': forms.TextInput(attrs={'placeholder': 'e.g. +964 123 456 7890'}),
            'availability_time': forms.TextInput(attrs={'placeholder': 'e.g. 9AM-5PM, Evenings only'}),
        }
        labels = {
            'contact_method': 'Preferred Contact Method',
            'availability_time': 'When are you available for contact?',
        }
