"""
URL configuration for market_project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
from django.views.generic import RedirectView
from market import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('login/', RedirectView.as_view(url='/accounts/login/', permanent=True), name='login_redirect'),
    path('accounts/login/', auth_views.LoginView.as_view(template_name='market/login.html'), name='login'),
    path('accounts/logout/', views.logout_view, name='logout'),
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    
    # Product management URLs
    path('products/', views.product_list, name='product_list'),
    path('products/<int:product_id>/', views.product_detail, name='product_detail'),
    
    # Admin routes
    path('manage/products/', views.product_list_admin, name='product_list_admin'),
    path('manage/products/add/', views.add_product, name='add_product'),
    path('manage/products/<int:product_id>/edit/', views.edit_product, name='edit_product'),
    path('manage/products/<int:product_id>/delete/', views.delete_product, name='delete_product'),
    path('manage/products/<int:product_id>/stock/', views.update_stock, name='update_stock'),
    
    # Category management URLs
    path('manage/categories/', views.category_list, name='category_list'),
    path('manage/categories/add/', views.add_category, name='add_category'),
    path('manage/categories/<int:category_id>/edit/', views.edit_category, name='edit_category'),
    path('manage/categories/<int:category_id>/delete/', views.delete_category, name='delete_category'),
    
    # API endpoints
    path('api/products/', views.api_products, name='api_products'),
    path('api/categories/', views.api_categories, name='api_categories'),
    path('api/products/<int:product_id>/', views.api_product, name='api_product'),
    
    # Cart functionality
    path('products/<int:product_id>/add-to-cart/', views.add_to_cart, name='add_to_cart'),
    path('manage/cart-requests/', views.cart_requests, name='cart_requests'),
    path('manage/cart-requests/<int:cart_id>/', views.cart_request_detail, name='cart_request_detail'),
    path('manage/cart-requests/<int:cart_id>/delete/', views.delete_cart_request, name='delete_cart_request'),
]

# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
