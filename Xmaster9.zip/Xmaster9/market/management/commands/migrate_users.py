from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
import os
import json

class Command(BaseCommand):
    help = 'Migrate users from JSON file to Django auth system'

    def handle(self, *args, **options):
        json_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'users.json')
        
        if not os.path.exists(json_path):
            self.stdout.write(self.style.ERROR('users.json not found'))
            return

        with open(json_path) as f:
            users = json.load(f)

        for user_data in users:
            username = user_data['username']
            if not User.objects.filter(username=username).exists():
                # Create user with a temporary password
                user = User.objects.create_user(
                    username=username,
                    password='password'  # This is the default password
                )
                user.is_superuser = True  # Since this was the admin user
                user.is_staff = True
                user.save()
                self.stdout.write(self.style.SUCCESS(f'Created user: {username}'))
            else:
                self.stdout.write(self.style.WARNING(f'User already exists: {username}'))
